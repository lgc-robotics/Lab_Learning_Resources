# -*-coding:utf-8-*-
import gym
import pybullet_envs.bullet.kukaCamGymEnv as e

# 该环境已经注释过，代码很简洁，值得学习
env = e.KukaCamGymEnv(isDiscrete=False, renders=False)

for i_episode in range(20):
    observation = env.reset()
    for t in range(100):
        # env.render()  # 没什么用
        # print(observation)
        action = env.action_space.sample()
        observation, reward, done, info = env.step(action)
        print(observation.shape)
        if done:
            print("Episode finished after {} timesteps".format(t + 1))
            break
env.close()
