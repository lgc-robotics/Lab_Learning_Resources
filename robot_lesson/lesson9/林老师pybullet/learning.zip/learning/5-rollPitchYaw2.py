# -*-coding:utf-8-*-
import pybullet_data
import time
import pybullet as p
import numpy as np

p.connect(p.GUI)

p.setAdditionalSearchPath(pybullet_data.getDataPath())
# q = p.loadURDF("quadruped/quadruped.urdf", useFixedBase=True)
rollId = p.addUserDebugParameter("roll", -np.pi, np.pi, 0)
pitchId = p.addUserDebugParameter("pitch", -np.pi, np.pi,  -np.pi/2)
yawId = p.addUserDebugParameter("yaw", 0, 2*np.pi, np.pi)

fwdxId = p.addUserDebugParameter("fwdxId", -1, 1, 0)
fwdyId = p.addUserDebugParameter("fwdyId", -1, 1, 0)
fwdzId = p.addUserDebugParameter("fwdzId", -1, 1, 0)

while True:
    roll = p.readUserDebugParameter(rollId)
    pitch = p.readUserDebugParameter(pitchId)
    yaw = p.readUserDebugParameter(yawId)

    x = p.readUserDebugParameter(fwdxId)
    y = p.readUserDebugParameter(fwdyId)
    z = p.readUserDebugParameter(fwdzId)

    orn = p.getQuaternionFromEuler([roll, pitch, yaw])

    rot_matrix = p.getMatrixFromQuaternion(orn)
    rot_matrix = np.array(rot_matrix).reshape(3, 3)

    endPos = np.array([0.5, 0.5, 0.3])

    p.addUserDebugLine(endPos, endPos + 0.1 * rot_matrix.dot((1, 0, 0)), (1, 0, 0), lifeTime=0.2)
    p.addUserDebugLine(endPos, endPos + 0.1 * rot_matrix.dot((0, 1, 0)), (0, 1, 0), lifeTime=0.2)
    p.addUserDebugLine(endPos, endPos + 0.1 * rot_matrix.dot((0, 0, 1)), (0, 0, 1), lifeTime=0.2)

