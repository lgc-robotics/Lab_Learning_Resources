# -*-coding:utf-8-*-
"""
原始的URDF文件里只有旋转副。
这个程序为齿轮添加齿轮副。
"""

import pybullet as p
import time
import pybullet_data

p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.resetDebugVisualizerCamera(cameraDistance=1.1, cameraYaw=3.6, cameraPitch=-27,
                             cameraTargetPosition=[0.19, 1.21, -0.44])

p.loadURDF("plane.urdf", [0, 0, -2])
wheelA = p.loadURDF("differential/diff_ring.urdf", [0, 0, 0])

# setJointMotorControl2不一定要放在while循环里面。
# 可放在while外面，因为一旦setJointMotorControl2被运行，并且while训练提供足够多的时间，
# 机器便能按setJointMotorControl2运行。见robotcontrol例子。
for i in range(p.getNumJoints(wheelA)):
    print(p.getJointInfo(wheelA, i))
    # 这个force似乎一直在，不能太大，否则它相当于阻力，后面的程序动不了
    p.setJointMotorControl2(wheelA, i, p.POSITION_CONTROL, targetVelocity=0, force=20)

is_constraint = 1
if is_constraint:
    c = p.createConstraint(wheelA,
                           1,
                           wheelA,
                           3,
                           jointType=p.JOINT_GEAR,
                           jointAxis=[0, 1, 0],
                           parentFramePosition=[0, 0, 0],
                           childFramePosition=[0, 0, 0]
                           )
    p.changeConstraint(c, gearRatio=1, maxForce=10000, erp=0.2)

    c = p.createConstraint(wheelA,
                           2,
                           wheelA,
                           4,
                           jointType=p.JOINT_GEAR,
                           jointAxis=[0, 1, 0],
                           parentFramePosition=[0, 0, 0],
                           childFramePosition=[0, 0, 0])
    p.changeConstraint(c, gearRatio=-1, maxForce=10000, erp=0.2)

    c = p.createConstraint(wheelA,
                           1,
                           wheelA,
                           4,
                           jointType=p.JOINT_GEAR,
                           jointAxis=[0, 1, 0],
                           parentFramePosition=[0, 0, 0],
                           childFramePosition=[0, 0, 0])
    p.changeConstraint(c, gearRatio=-1, maxForce=10000, erp=0.2)

# 为什么重力不起作用，想不懂
p.setGravity(0, 0, -10)
p.setRealTimeSimulation(1)
while 1:
    time.sleep(0.01)
# p.removeConstraint(c)
