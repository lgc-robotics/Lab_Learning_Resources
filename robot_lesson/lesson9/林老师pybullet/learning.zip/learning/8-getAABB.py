# -*-coding:utf-8-*-
import pybullet as p
import pybullet_data

draw = 1
printtext = 1

if draw:
    p.connect(p.GUI)
else:
    p.connect(p.DIRECT)

p.setAdditionalSearchPath(pybullet_data.getDataPath())
r2d2 = p.loadURDF("r2d2.urdf")


def drawAABB(aabbMin, aabbMax):
    """该函数用于绘制一个link的外接矩形，要求输入两个对角点
    """
    liftTime = 0
    # 下面相当于画一个坐标系的三条轴
    # 使用红色线条画一条水平线
    f = [aabbMin[0], aabbMin[1], aabbMin[2]]
    t = [aabbMax[0], aabbMin[1], aabbMin[2]]
    p.addUserDebugLine(f, t, [1, 0, 0], lifeTime=liftTime)
    # 使用蓝色线条画一条垂直线
    f = [aabbMin[0], aabbMin[1], aabbMin[2]]
    t = [aabbMin[0], aabbMax[1], aabbMin[2]]
    p.addUserDebugLine(f, t, [0, 1, 0], lifeTime=liftTime)
    # 使用绿色线条画一条水平线
    f = [aabbMin[0], aabbMin[1], aabbMin[2]]
    t = [aabbMin[0], aabbMin[1], aabbMax[2]]
    p.addUserDebugLine(f, t, [0, 0, 1], lifeTime=liftTime)

    # 绘制其他边
    f = [aabbMin[0], aabbMin[1], aabbMax[2]]
    t = [aabbMin[0], aabbMax[1], aabbMax[2]]
    p.addUserDebugLine(f, t, [1, 1, 1], lifeTime=liftTime)

    f = [aabbMin[0], aabbMin[1], aabbMax[2]]
    t = [aabbMax[0], aabbMin[1], aabbMax[2]]
    p.addUserDebugLine(f, t, [1, 1, 1], lifeTime=liftTime)

    f = [aabbMax[0], aabbMin[1], aabbMin[2]]
    t = [aabbMax[0], aabbMin[1], aabbMax[2]]
    p.addUserDebugLine(f, t, [1, 1, 1], lifeTime=liftTime)

    f = [aabbMax[0], aabbMin[1], aabbMin[2]]
    t = [aabbMax[0], aabbMax[1], aabbMin[2]]
    p.addUserDebugLine(f, t, [1, 1, 1], lifeTime=liftTime)

    f = [aabbMax[0], aabbMax[1], aabbMin[2]]
    t = [aabbMin[0], aabbMax[1], aabbMin[2]]
    p.addUserDebugLine(f, t, [1, 1, 1], lifeTime=liftTime)

    f = [aabbMin[0], aabbMax[1], aabbMin[2]]
    t = [aabbMin[0], aabbMax[1], aabbMax[2]]
    p.addUserDebugLine(f, t, [1, 1, 1], lifeTime=liftTime)

    f = [aabbMax[0], aabbMax[1], aabbMax[2]]
    t = [aabbMin[0], aabbMax[1], aabbMax[2]]
    p.addUserDebugLine(f, t, [1.0, 0.5, 0.5], lifeTime=liftTime)
    f = [aabbMax[0], aabbMax[1], aabbMax[2]]
    t = [aabbMax[0], aabbMin[1], aabbMax[2]]
    p.addUserDebugLine(f, t, [1, 1, 1], lifeTime=liftTime)
    f = [aabbMax[0], aabbMax[1], aabbMax[2]]
    t = [aabbMax[0], aabbMax[1], aabbMin[2]]
    p.addUserDebugLine(f, t, [1, 1, 1], lifeTime=liftTime)


# 获取base的axis aligned bounding box
aabb = p.getAABB(r2d2)
aabbMin = aabb[0]
aabbMax = aabb[1]
if printtext:
    print(aabbMin)
    print(aabbMax)
if draw == 1:
    drawAABB(aabbMin, aabbMax)

for i in range(p.getNumJoints(r2d2)):
    aabb = p.getAABB(r2d2, i)
    aabbMin = aabb[0]
    aabbMax = aabb[1]
    if printtext:
        print(aabbMin)
        print(aabbMax)
    if draw == 1:
        drawAABB(aabbMin, aabbMax)

while 1:
    p.stepSimulation()
