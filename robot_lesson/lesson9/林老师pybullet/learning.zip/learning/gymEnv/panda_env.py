# -*-coding:utf-8-*-
import gym
from gym import error, spaces, utils
from gym.utils import seeding

import os
import pybullet_data
import pybullet as p
import math
import numpy as np
import random


class PandaEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self):
        p.connect(p.GUI)
        # 设置环境观测视角，不是用来生成图像的。
        p.resetDebugVisualizerCamera(cameraDistance=1.5, cameraYaw=0, cameraPitch=-40,
                                     cameraTargetPosition=[0.55, -0.35, 0.2])
        self.action_space = spaces.Box(np.array([-1] * 4), np.array([1] * 4))
        self.observation_space = spaces.Box(np.array([-1] * 5), np.array([1] * 5))

    def step(self, action):
        p.configureDebugVisualizer(p.COV_ENABLE_SINGLE_STEP_RENDERING)
        # 确保末端朝下
        orientation = p.getQuaternionFromEuler([0, -math.pi, math.pi / 2])
        dv = 0.005
        dx = action[0] * dv
        dy = action[1] * dv
        dz = action[2] * dv
        fingers = action[3]

        # end-effector
        currentPose = p.getLinkState(self.pandaUid, 11)
        currentPosition = currentPose[0]
        newPosition = [currentPosition[0] + dx,
                       currentPosition[1] + dy,
                       currentPosition[2] + dz]
        # 返回元组，并不是列表
        jointPoses = p.calculateInverseKinematics(self.pandaUid, 11, newPosition, orientation)

        p.setJointMotorControlArray(self.pandaUid,
                                    list(range(7)) + [9, 10],
                                    p.POSITION_CONTROL,
                                    list(jointPoses[:-2]) + 2 * [fingers])
        p.stepSimulation()

        state_object, _ = p.getBasePositionAndOrientation(self.objectUid)
        state_robot = p.getLinkState(self.pandaUid, 11)[0]  # 位置
        state_fingers = (p.getJointState(self.pandaUid, 9)[0], p.getJointState(self.pandaUid, 10)[0])
        # 一旦物体被抬高到一定距离，便认为抓取成功
        if state_object[2] > 0.45:
            reward = 1
            done = True
        else:
            reward = 0
            done = False
        info = state_object
        observation = state_robot + state_fingers
        return observation, reward, done, info

    def render(self, mode='human'):
        view_matrix = p.computeViewMatrixFromYawPitchRoll(cameraTargetPosition=[0.7, 0, 0.05],
                                                          distance=0.7,
                                                          yaw=90,
                                                          pitch=-70,
                                                          roll=0,
                                                          upAxisIndex=2
                                                          )
        proj_matrix = p.computeProjectionMatrixFOV(fov=60,
                                                   aspect=float(960) / 720,
                                                   nearVal=0.1,
                                                   farVal=100.0)
        # 运行了这行代码，pybullet不仅能返回图像，还是直接可视化图像
        img_info = p.getCameraImage(width=960,
                                    height=720,
                                    viewMatrix=view_matrix,
                                    projectionMatrix=proj_matrix,
                                    renderer=p.ER_BULLET_HARDWARE_OPENGL)

        rgb = img_info[2][:, :, :4]
        depth = img_info[3]
        # (unit8, float)
        return rgb, depth

    def reset(self):
        p.resetSimulation()
        # 加载模型阶段，暂时关掉渲染
        p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 0)
        p.setGravity(0, 0, -10)

        urdfRootPath = pybullet_data.getDataPath()
        planeUid = p.loadURDF(os.path.join(urdfRootPath, "plane.urdf"),
                              basePosition=[0, 0, -0.65])

        rest_poses = [0, -0.215, 0, -2.57, 0, 2.356, 2.356, 0.08, 0.08]
        self.pandaUid = p.loadURDF(os.path.join(urdfRootPath, "franka_panda/panda.urdf"),
                                   useFixedBase=True)
        for i in range(7):
            p.resetJointState(self.pandaUid, i, rest_poses[i])

        tableUid = p.loadURDF(os.path.join(urdfRootPath, "table/table.urdf"),
                              basePosition=[0.5, 0, -0.65])

        trayUid = p.loadURDF(os.path.join(urdfRootPath, "tray/traybox.urdf"),
                             basePosition=[0.65, 0, 0])   # 它的质量为0，所以不会跌落，但仍能够进行碰撞

        state_object = [random.uniform(0.5, 0.8), random.uniform(-0.2, 0.2), 0.05]
        self.objectUid = p.loadURDF(os.path.join(urdfRootPath, "random_urdfs/000/000.urdf"),
                                    basePosition=state_object)

        # 末端位置
        state_robot = p.getLinkState(self.pandaUid, 11)[0]
        # 手指状态
        state_fingers = (p.getJointState(self.pandaUid, 9)[0], p.getJointState(self.pandaUid, 10)[0])
        # 列表，长度为5
        observation = state_robot + state_fingers
        # 启用渲染
        p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 1)
        return observation

    def close(self):
        p.disconnect()


if __name__ == "__main__":
    env = PandaEnv()
    for i_episode in range(20):
        observation = env.reset()
        for t in range(100):
            env.render()
            print(observation)
            action = env.action_space.sample()
            observation, reward, done, info = env.step(action)
            if done:
                print("Episode finished after {} timesteps".format(t + 1))
                break
    env.close()
