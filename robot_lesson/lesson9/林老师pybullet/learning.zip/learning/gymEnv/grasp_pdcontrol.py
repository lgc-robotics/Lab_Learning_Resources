# -*-coding:utf-8-*-
from panda_env import PandaEnv

done = False
error = 0.01
fingers = 1
info = [0.7, 0, 0.1]   # 物体的真实位置。初始值是猜的。

k_p = 10
k_d = 1
dt = 1. / 240.  # the default timestep in pybullet is 240 Hz
t = 4

env = PandaEnv()
for i_episode in range(20):
    obs = env.reset()
    fingers = 1
    for t in range(100):
        env.render()
        print(obs)
        dx = info[0] - obs[0]
        dy = info[1] - obs[1]

        target_z = info[2]

        if abs(dx) < error and abs(dy) < error and abs(dz) < error:
            fingers = 0
        if (obs[3] + obs[4]) < error + 0.02 and fingers == 0:
            target_z = 0.5   # 一旦夹持物体，便抬高到0.5m处。

        dz = target_z - obs[2]
        pd_x = k_p*dx+k_d*dx/dt
        pd_y = k_p*dy+k_d*dy/dt
        pd_z = k_p*dz+k_d*dz/dt
        act = [pd_x, pd_y, pd_z, fingers]

        obs, reward, done, info = env.step(act)
        if done:
            print("Episode finished after {} timesteps".format(t + 1))
            break
env.close()
