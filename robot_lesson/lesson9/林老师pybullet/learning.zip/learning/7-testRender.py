# -*-coding:utf-8-*-
import numpy as np
import matplotlib.pyplot as plt
import pybullet
import pybullet_data
import time

plt.ion()  # 打开交互模式
# plt.ioff()  # 关闭交互模式
# plt.clf()  # 清除当前的Figure对象
# plt.cla()  # 清除当前的Axes对象
# plt.pause()  # 暂停功能

img = np.random.rand(200, 300)
image = plt.imshow(img, interpolation='none', animated=True, label='blah')
ax = plt.gca()

pybullet.connect(pybullet.GUI)
#pybullet.connect(pybullet.DIRECT)

pybullet.setAdditionalSearchPath(pybullet_data.getDataPath())
pybullet.loadURDF("plane.urdf", [0, 0, 0])
pybullet.loadURDF("r2d2.urdf", [0, 0, 1])
pybullet.setGravity(0, 0, -10)

camTargetPos = [0, 0, 0]
camDistance = 1
upAxisIndex = 2
pitch = -10.0
roll = 0

pixelWidth = 320
pixelHeight = 200
nearPlane = 0.01
farPlane = 100
fov = 60

main_start = time.time()
while True:
    for yaw in range(0, 360, 10):
        pybullet.stepSimulation()
        start = time.time()
        viewMatrix = pybullet.computeViewMatrixFromYawPitchRoll(camTargetPos,  # 相机所聚焦的位置，不是相机位置
                                                                camDistance,  # 不是焦距，是相机到聚焦点的直线距离。直线的方位由yaw、pitch、roll决定。
                                                                yaw,
                                                                pitch,
                                                                roll,
                                                                upAxisIndex)
        aspect = pixelWidth / pixelHeight
        projectionMatrix = pybullet.computeProjectionMatrixFOV(fov, aspect, nearPlane, farPlane)
        # 返回一个列表，包含RGB、深度、语义分割图
        img_arr = pybullet.getCameraImage(pixelWidth,
                                          pixelHeight,
                                          viewMatrix,
                                          projectionMatrix,
                                          shadow=1,
                                          lightDirection=[1, 1, 1],
                                          renderer=pybullet.ER_BULLET_HARDWARE_OPENGL)
        stop = time.time()
        print("renderImage %f" % (stop - start))

        w = img_arr[0]  # width of the image, in pixels
        h = img_arr[1]  # height of the image, in pixels
        # (200, 320, 3)
        rgb = img_arr[2]  # color data RGB
        dep = img_arr[3]  # depth data
        print('width = %d height = %d' % (w, h))
        print(rgb.shape)

        image = plt.imshow(rgb, interpolation='none')
        plt.pause(0.01)
main_stop = time.time()
print("Total time %f" % (main_stop - main_start))
pybullet.resetSimulation()
