# -*-coding:utf-8-*-
import pybullet as p
import time
import pybullet_data


p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.loadURDF("plane.urdf", [0, 0, 0])
useCollisionShapeQuery = False
# 这条语句还是有差别的，显示效果不一样
p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)
geom = p.createCollisionShape(p.GEOM_SPHERE, radius=0.1)
geomBox = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.2, 0.2, 0.2])
baseOrientationB = p.getQuaternionFromEuler([0, 0.3, 0])  #[0,0.5,0.5,0]
basePositionB = [1.5, 0, 1]
obA = -1
obB = -1

obA = p.createMultiBody(baseMass=0.1,
                        baseCollisionShapeIndex=geom,
                        basePosition=[0.5, 0, 1])
obB = p.createMultiBody(baseMass=0.1,
                        baseCollisionShapeIndex=geomBox,
                        basePosition=basePositionB,
                        baseOrientation=baseOrientationB)

lineWidth = 3
colorRGB = [1, 0, 0]
lineId = p.addUserDebugLine(lineFromXYZ=[0, 0, 0],
                            lineToXYZ=[0, 0, 0],
                            lineColorRGB=colorRGB,
                            lineWidth=lineWidth,
                            lifeTime=0)
pitch = 0
yaw = 0

p.setGravity(0, 0, -10)
while 1:
    pitch += 0.01
    if pitch >= 3.1415 * 2.:
        pitch = 0
    yaw += 0.01
    if yaw >= 3.1415 * 2.:
        yaw = 0

    baseOrientationB = p.getQuaternionFromEuler([yaw, pitch, 0])
    if obB >= 0:
        p.resetBasePositionAndOrientation(obB, basePositionB, baseOrientationB)

    if useCollisionShapeQuery:
        # 这种方法看起来复杂，实际上由于知道了很多信息，所以计算效率高
        # 这个方法有很大的漏洞，就是它固定死bodyA和bodyB的位置进行计算。
        # 当然，如果把位置和姿态传进去，也是可以算的。
        pts = p.getClosestPoints(bodyA=-1,
                                 bodyB=-1,
                                 distance=100,
                                 collisionShapeA=geom,
                                 collisionShapeB=geomBox,
                                 collisionShapePositionA=[0.5, 0, 1],
                                 collisionShapePositionB=basePositionB,
                                 collisionShapeOrientationB=baseOrientationB
                                 )
    else:
        # 当物体的位置在不断变化时，并且这种变化是未知的，可以用这种方法。
        pts = p.getClosestPoints(bodyA=obA,
                                 bodyB=obB,
                                 distance=100)
        contacts = p.getContactPoints(bodyA=obA,
                                      bodyB=obB)
    if len(contacts) > 0:
        print("contact happen!!!")

    if len(pts) > 0:
        distance = pts[0][8]
        ptA = pts[0][5]
        ptB = pts[0][6]
        p.addUserDebugLine(lineFromXYZ=ptA,
                           lineToXYZ=ptB,
                           lineColorRGB=colorRGB,
                           lineWidth=lineWidth,
                           lifeTime=0,
                           replaceItemUniqueId=lineId)
    time.sleep(1./240.)
    p.stepSimulation()
