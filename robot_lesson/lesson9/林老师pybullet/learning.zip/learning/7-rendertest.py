# -*-coding:utf-8-*-
"""
重要程序，需要复现

"""

import time
import itertools
import numpy as np
import matplotlib.pyplot as plt

import pybullet_data
import pybullet

camTargetPos = [0, 0, 0]
cameraUp = [0, 0, 1]
cameraPos = [1, 1, 1]

pitch = -10
roll = 0
upAxisIndes = 2
camDistance = 4
pixelWidth = 96
pixelHeight = 96
nearPlane = 0.01
farPlane = 100
fov = 60

# 把大界面缩放为（pixelWidth，pixelHeight），会影响后面getCameraImage所生成图像的分辨率
print("connecting")
connection_mode = pybullet.GUI
optionstring = '--width={} --height={}'.format(pixelWidth, pixelHeight)
optionstring += ' --window_backend=2 --render_device=0'
cid = pybullet.connect(connection_mode, options=optionstring)
pybullet.setAdditionalSearchPath(pybullet_data.getDataPath())
if cid < 0:
    raise ValueError
print("connected")


# 这个函数常用语激活或抑制某些显示功能，在算力比较差的硬件上常用
# 我认为是关掉预览功能，节省计算量和缓存
pybullet.configureDebugVisualizer(pybullet.COV_ENABLE_GUI, 0)
pybullet.configureDebugVisualizer(pybullet.COV_ENABLE_SEGMENTATION_MARK_PREVIEW, 0)
pybullet.configureDebugVisualizer(pybullet.COV_ENABLE_DEPTH_BUFFER_PREVIEW, 0)
pybullet.configureDebugVisualizer(pybullet.COV_ENABLE_RGB_BUFFER_PREVIEW, 0)

pybullet.resetSimulation()
pybullet.loadURDF("plane.urdf", [0, 0, -1])
pybullet.loadURDF("r2d2.urdf")
pybullet.loadURDF("duck_vhacd.urdf")
pybullet.setGravity(0, 0, -10)

num_runs = 800
shadow = 1
log = False
plot = True

if log:
    logId = pybullet.startStateLogging(pybullet.STATE_LOGGING_PROFILE_TIMINGS, "renderTimings")

if plot:
    plt.ion()
    img = np.random.rand(pixelHeight, pixelHeight)
    image = plt.imshow(img, interpolation='none', animated=True, label="blah")
    #ax = plt.gca()

times = np.zeros(num_runs)
yaw_gen = itertools.cycle(range(0, 360, 10))
for i, yaw in zip(range(num_runs), yaw_gen):
    pybullet.stepSimulation()
    start = time.time()
    viewMatrix = pybullet.computeViewMatrixFromYawPitchRoll(camTargetPos,
                                                            camDistance,
                                                            yaw,
                                                            pitch,
                                                            roll,
                                                            upAxisIndes)
    aspect = pixelWidth / pixelHeight
    projectionMatrix = pybullet.computeProjectionMatrixFOV(fov, aspect, nearPlane, farPlane)
    img_arr = pybullet.getCameraImage(pixelWidth,
                                      pixelHeight,
                                      viewMatrix,
                                      projectionMatrix,
                                      shadow=shadow,
                                      lightDirection=[1, 1, 1],
                                      renderer=pybullet.ER_BULLET_HARDWARE_OPENGL)
    # 图像生成时间
    stop = time.time()
    duration = (stop - start)
    if duration:
        fps = 1. / duration
    else:
        fps = 0

    times[i] = fps

    if plot:
        rgb = img_arr[2]
        image.set_data(rgb)  # np_img_arr)
        #ax.plot([0])
        image = plt.imshow(rgb, interpolation='none')
        plt.pause(0.01)

mean_time = float(np.mean(times))
print("mean: {0} for {1} runs".format(mean_time, num_runs))
if log:
    pybullet.stopStateLogging(logId)
