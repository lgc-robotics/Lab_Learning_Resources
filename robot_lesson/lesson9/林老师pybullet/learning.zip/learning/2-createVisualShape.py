# -*-coding:utf-8-*-
import pybullet as p
import time
import math
import pybullet_data

"""
生成很多小鸭子
"""

cid = p.connect(p.SHARED_MEMORY)
if (cid < 0):
    p.connect(p.GUI)

p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setPhysicsEngineParameter(numSolverIterations=10)
p.setTimeStep(1. / 120.)
logId = p.startStateLogging(p.STATE_LOGGING_PROFILE_TIMINGS, "visualShapeBench.json")
p.loadURDF("plane100.urdf")

# 在创建实例前，把render关掉
p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 0)
p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)
p.configureDebugVisualizer(p.COV_ENABLE_TINY_RENDERER, 0)

shift = [0, -0.02, 0]
meshScale = [0.5, 0.5, 0.5]
visualShapeId = p.createVisualShape(shapeType=p.GEOM_MESH,
                                    fileName='duck.obj',
                                    rgbaColor=[1, 1, 1, 1],
                                    specularColor=[0.4, 0.4, 0],
                                    visualFramePosition=shift,
                                    meshScale=meshScale)

collisionShapeId = p.createCollisionShape(shapeType=p.GEOM_MESH,
                                          fileName='duck_vhacd.obj',
                                          collisionFramePosition=shift,
                                          meshScale=meshScale)
rangex = 10
rangey = 2
for i in range(rangex):
    for j in range(rangey):
        p.createMultiBody(baseMass=1,
                          baseInertialFramePosition=[0, 0, 0],
                          baseCollisionShapeIndex=collisionShapeId,
                          baseVisualShapeIndex=visualShapeId,
                          basePosition=[((-rangex / 2) + i) * meshScale[0] * 2,
                                        (-rangey / 2 + j) * meshScale[1] * 2, 1],
                          useMaximalCoordinates=True)

p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 1)
p.stopStateLogging(logId)
p.setGravity(0, 0, -10)
p.setRealTimeSimulation(1)

while 1:
    time.sleep(1. / 240.)
