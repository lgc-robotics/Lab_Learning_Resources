# -*-coding:utf-8-*-
import pybullet as p
from pdControllerExplicit import PDControllerExplicitMultiDof
from pdControllerExplicit import PDControllerExplicit
from pdControllerStable import PDControllerStable
import pybullet_data
import time

useMaximalCoordinates = False
p.connect(p.GUI)

p.setAdditionalSearchPath(pybullet_data.getDataPath())
pole1 = p.loadURDF("cartpole.urdf", [0, 0, 0], useMaximalCoordinates=useMaximalCoordinates)
pole2 = p.loadURDF("cartpole.urdf", [0, 1, 0], useMaximalCoordinates=useMaximalCoordinates)
pole3 = p.loadURDF("cartpole.urdf", [0, 2, 0], useMaximalCoordinates=useMaximalCoordinates)
pole4 = p.loadURDF("cartpole.urdf", [0, 3, 0], useMaximalCoordinates=useMaximalCoordinates)

exPD = PDControllerExplicitMultiDof(p)
sPD = PDControllerStable(p)

for i in range(p.getNumJoints(pole2)):
    # disable default constraint-based motors
    # cartpole有两个关节，把两个关节的位置清0。
    p.setJointMotorControl2(pole1, i, p.POSITION_CONTROL, targetPosition=0, force=0)
    p.setJointMotorControl2(pole2, i, p.POSITION_CONTROL, targetPosition=0, force=0)
    p.setJointMotorControl2(pole3, i, p.POSITION_CONTROL, targetPosition=0, force=0)
    p.setJointMotorControl2(pole4, i, p.POSITION_CONTROL, targetPosition=0, force=0)

# 创建滑动条，用于调试
timeStepId = p.addUserDebugParameter("timeStep", 0.001, 0.1, 0.01)
desiredPosCartId = p.addUserDebugParameter("desiredPosCart", -10, 10, 2)
desiredVelCartId = p.addUserDebugParameter("desiredVelCart", -10, 10, 0)
kpCartId = p.addUserDebugParameter("kpCart", 0, 500, 1300)
kdCartId = p.addUserDebugParameter("kdCart", 0, 300, 150)
maxForceCartId = p.addUserDebugParameter("maxForceCart", 0, 5000, 1000)

textColor = [1, 1, 1]
shift = 0.05
# 以ObjectUniqueId/LinkIndex的坐标系为基准，在textPosition位置处添加文字
# 所以它们变成了parent
p.addUserDebugText("explicit PD",
                   [shift, 0, 0.1],
                   textColor,
                   parentObjectUniqueId=pole1,
                   parentLinkIndex=1)
p.addUserDebugText("explicit PD plugin", [shift, 0, -.1],
                   textColor,
                   parentObjectUniqueId=pole2,
                   parentLinkIndex=1)
p.addUserDebugText("stablePD", [shift, 0, .1],
                   textColor,
                   parentObjectUniqueId=pole4,
                   parentLinkIndex=1)
p.addUserDebugText("position constraint", [shift, 0, -.1],
                   textColor,
                   parentObjectUniqueId=pole3,
                   parentLinkIndex=1)

desiredPosPoleId = p.addUserDebugParameter("desiredPosPole", -10, 10, 0)
desiredVelPoleId = p.addUserDebugParameter("desiredVelPole", -10, 10, 0)
kpPoleId = p.addUserDebugParameter("kpPole", 0, 500, 1200)
kdPoleId = p.addUserDebugParameter("kdPole", 0, 300, 100)  # 接近于0时，有利于提高模型稳定性
maxForcePoleId = p.addUserDebugParameter("maxForcePole", 0, 5000, 1000)

# 用于可视化
# p.setRealTimeSimulation(1)
# while 1:
#    time.sleep(0.001)
pd = p.loadPlugin("pdControlPlugin")
p.setGravity(0, 0, -10)
useRealTimeSim = False
p.setRealTimeSimulation(useRealTimeSim)
timeStep = 0.001
while p.isConnected():
    timeStep = p.readUserDebugParameter(timeStepId)
    p.setTimeStep(timeStep)  # 默认值是240

    # cart指小车
    desiredPosCart = p.readUserDebugParameter(desiredPosCartId)
    desiredVelCart = p.readUserDebugParameter(desiredVelCartId)
    kpCart = p.readUserDebugParameter(kpCartId)
    kdCart = p.readUserDebugParameter(kdCartId)
    maxForceCart = p.readUserDebugParameter(maxForceCartId)

    # pole指立杆
    desiredPosPole = p.readUserDebugParameter(desiredPosPoleId)
    desiredVelPole = p.readUserDebugParameter(desiredVelPoleId)
    kpPole = p.readUserDebugParameter(kpPoleId)
    kdPole = p.readUserDebugParameter(kdPoleId)
    maxForcePole = p.readUserDebugParameter(maxForcePoleId)

    # 控制pole1
    # 这里的base指固定不动、水平状态的长杆
    basePos, baseOrn = p.getBasePositionAndOrientation(pole1)
    baseDof = 7
    taus = exPD.computePD(pole1,
                          [0, 1],
                          [basePos[0], basePos[1], basePos[2], baseOrn[0], baseOrn[1], baseOrn[2], baseOrn[3],
                           desiredPosCart, desiredPosPole],
                          [0, 0, 0, 0, 0, 0, 0, desiredVelCart, desiredVelPole],
                          [0, 0, 0, 0, 0, 0, 0, kpCart, kpPole],
                          [0, 0, 0, 0, 0, 0, 0, kdCart, kdPole],
                          [0, 0, 0, 0, 0, 0, 0, maxForceCart, maxForcePole],
                          timeStep)

    cart_info = p.getJointState(pole1, 0)
    pole_info = p.getJointState(pole1, 1)
    print("对于pole1对象，它的cart和pole的期望位置：", desiredPosCart, desiredPosPole)
    print("对于pole1对象，它的cart和pole的实际位置：", cart_info[0], pole_info[0])
    for j in [0, 1]:
        p.setJointMotorControlMultiDof(pole1,
                                       j,
                                       controlMode=p.TORQUE_CONTROL,
                                       force=[taus[j + baseDof]])
    # 控制pole2
    taus = sPD.computePD(pole2,
                         [0, 1],
                         [desiredPosCart, desiredPosPole],
                         [desiredVelCart, desiredVelPole],
                         [kpCart, kpPole],
                         [kdCart, kdPole],
                         [maxForceCart, maxForcePole],
                         timeStep)

    cart_info = p.getJointState(pole2, 0)
    pole_info = p.getJointState(pole2, 1)
    print("对于pole2对象，它的cart和pole的期望位置：", desiredPosCart, desiredPosPole)
    print("对于pole2对象，它的cart和pole的实际位置：", cart_info[0], pole_info[0])
    for j in [0, 1]:
        p.setJointMotorControlMultiDof(pole2,
                                       j,
                                       controlMode=p.TORQUE_CONTROL,
                                       force=[taus[j]])

    # 控制pole3
    cart_info = p.getJointState(pole3, 0)
    pole_info = p.getJointState(pole3, 1)
    print("对于pole3对象，它的cart和pole的期望位置：", desiredPosCart, desiredPosPole)
    print("对于pole3对象，它的cart和pole的实际位置：", cart_info[0], pole_info[0])
    # 控制pole2对象
    # 注意：在POSITION_CONTROL模式下，我们的目标是获得targetPosition，而不是targetVelocity。
    # 这不意味着targetVelocity和velocityGain要设置为0；这两个值设置为某个值时，会有利于算法收敛。
    # pybullet是用C + +写的，最底层的代码看不到，我们可以通过试验倒推出它的算法原理。
    # 对于POSITION_CONTROL，它用到了targetVelocity和velocityGain两个信息来设计算法。
    link = 0
    p.setJointMotorControl2(bodyUniqueId=pole3,
                            jointIndex=link,
                            controlMode=p.POSITION_CONTROL,
                            targetPosition=desiredPosCart,
                            targetVelocity=desiredVelCart,  # 在位置控制时，这个不一定要设置为0。具体原因看setJointMotorControl2的源码了
                            velocityGain=1,  # 在位置控制时，这个不一定要设置为0。具体原因看setJointMotorControl2的源码了
                            force=maxForceCart,
                            positionGain=1,
                            )
    link = 1
    p.setJointMotorControl2(bodyUniqueId=pole3,
                            jointIndex=link,
                            controlMode=p.POSITION_CONTROL,
                            targetPosition=desiredPosPole,
                            targetVelocity=desiredVelPole,  # 在位置控制时，这个不一定要设置为0。具体原因看setJointMotorControl2的源码了
                            velocityGain=1,  # 在位置控制时，这个不一定要设置为0。具体原因看setJointMotorControl2的源码了
                            force=maxForcePole,
                            positionGain=1,
                            )

    # 控制pole3和pole4对象，不写了

    if not useRealTimeSim:
        p.stepSimulation()
        time.sleep(timeStep)
