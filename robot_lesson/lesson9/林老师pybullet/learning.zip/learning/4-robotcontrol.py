# -*-coding:utf-8-*-
import pybullet as p
import pybullet_data
import time

p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())

p.loadURDF("plane.urdf")
p.setGravity(0, 0, -10)

# 下面的语句可用于显示
# 如果用了setRealTimeSimulation，就不用stepSimulation
# p.setRealTimeSimulation(1)
# while 1:
#    time.sleep(0.01)

startPos = [0, 0, 0]
startOrn = p.getQuaternionFromEuler([0, 0, 0])
husky = p.loadURDF("husky/husky.urdf", startPos, startOrn)
numJoints = p.getNumJoints(husky)
print("num joints=", numJoints)

for joint in range(numJoints):
    print(p.getJointInfo(husky, joint))
targetVel = 10  # rad/s
maxForce = 1000

print("forward...")
for joint in range(2, 6):
    p.setJointMotorControl2(husky, joint, p.VELOCITY_CONTROL, targetVelocity=targetVel, force=maxForce, velocityGain=1)
for step in range(500):
    p.stepSimulation()
    time.sleep(1. / 240.)

print("backward...")
targetVel = -10
for joint in range(2, 6):
    p.setJointMotorControl2(husky, joint, p.VELOCITY_CONTROL, targetVelocity=targetVel, force=maxForce,velocityGain=1)
for step in range(500):
    p.stepSimulation()
    time.sleep(1. / 240.)

p.getContactPoints(husky)
p.disconnect()
