# -*-coding:utf-8-*-
import pybullet as p
import time
import math
from datetime import datetime
import pybullet_data

p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.loadURDF("plane.urdf", [0, 0, -0.3])
kukaId = p.loadURDF("kuka_iiwa/model.urdf", [0, 0, 0])
p.resetBasePositionAndOrientation(kukaId, [0, 0, 0], [0, 0, 0, 1])
kukaEndEffectorIndex = 6
numJoints = p.getNumJoints(kukaId)
if numJoints != 7:
    exit()

# lower limits
ll = [-.967, -2, -2.96, 0.19, -2.96, -2.09, -3.05]
# upper limits
ul = [.967, 2, 2.96, 2.29, 2.96, 2.09, 3.05]
# joint ranges：未理解
jr = [5.8, 4, 5.8, 4, 5.8, 4, 6]
# restposes：我认为是设置机器人的初始位姿
rp = [0, 0, 0, 0.5 * math.pi, 0, -math.pi * 0.5 * 0.66, 0]
# 关节阻尼系数damping coefficents
jd = [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1]

for i in range(numJoints):
    p.resetJointState(kukaId, i, rp[i])

p.setGravity(0, 0, 0)
t = 0
prevPose = [0, 0, 0]
prevPose1 = [0, 0, 0]
hasPrevPose = 0
useNullSpace = 1
useOrientation = 1

# 如果我们设置useSimulation=0，那么相当于机械臂不受动力系统控制，可以更好地检验IK精度
# 我们不一定要用p.stepSimulation()进行可视化，只要while一直在走。为了让机器人能动，此时可用p.resetJointState
useSimulation = 1
useRealTimeSimulation = 0
ikSolver = 0
# 若果setRealTimeSimulation被设置，那么就不用stepSimulation
p.setRealTimeSimulation(useRealTimeSimulation)
trailDuration = 15  # 秒

i = 0
while 1:
    i += 1
    if useRealTimeSimulation:
        dt = datetime.now()
        t = (dt.second / 60.) * 2 * math.pi
        print(t)
    else:
        t = t + 0.01

    if useSimulation and useRealTimeSimulation == 0:
        p.stepSimulation()

    for i in range(1):
        pos = [-0.4, 0.2 * math.cos(t), 0. + 0.2 * math.sin(t)]
        orn = p.getQuaternionFromEuler([0, -math.pi, 0])

        if useNullSpace == 1:
            if useOrientation == 1:
                jointPoses = p.calculateInverseKinematics(kukaId,
                                                          kukaEndEffectorIndex,  # 末端执行器的连杆编号
                                                          pos,  # 目标位置
                                                          orn,  # 目标姿态
                                                          lowerLimits=ll,  # 关节下限值
                                                          upperLimits=ul,  # 关节上限值
                                                          jointRanges=jr,  # 关节范围，和下限上限的区别是什么？
                                                          restPoses=rp,  # 是不是初值？
                                                          )
            else:
                jointPoses = p.calculateInverseKinematics(kukaId,
                                                          kukaEndEffectorIndex,
                                                          pos,
                                                          lowerLimits=ll,
                                                          upperLimits=ul,
                                                          jointRanges=jr,
                                                          restPoses=rp)
        else:
            if useOrientation == 1:
                jointPoses = p.calculateInverseKinematics(kukaId,
                                                          kukaEndEffectorIndex,
                                                          pos,
                                                          orn,
                                                          jointDamping=jd,
                                                          solver=ikSolver,
                                                          )
            else:
                jointPoses = p.calculateInverseKinematics(kukaId,
                                                          kukaEndEffectorIndex,
                                                          pos,
                                                          solver=ikSolver)
        # 显示反解结果
        if useSimulation:
            for j in range(numJoints):
                p.setJointMotorControl2(bodyIndex=kukaId,
                                        jointIndex=j,
                                        controlMode=p.POSITION_CONTROL,
                                        targetPosition=jointPoses[j],
                                        targetVelocity=0,
                                        force=500,
                                        positionGain=0.03,
                                        velocityGain=1)
        else:
            for j in range(numJoints):
                p.resetJointState(kukaId, j, jointPoses[j])

    ls = p.getLinkState(kukaId, kukaEndEffectorIndex)
    if hasPrevPose:
        # 起点vec3、端点vec3、颜色vec3、线宽、持续时间
        p.addUserDebugLine(prevPose, pos, [0, 0, 0.3], 1, trailDuration)
        p.addUserDebugLine(prevPose1, ls[4], [1, 0, 0], 1, trailDuration)
    prevPose = pos
    prevPose1 = ls[4]
    hasPrevPose = 1

p.disconnect()
