# -*-coding:utf-8-*-
import pybullet as p
import time
import pybullet_data

p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.createCollisionShape(p.GEOM_PLANE)
p.createMultiBody(0, 0)

sphereRadius = 0.05
colSphereId = p.createCollisionShape(p.GEOM_SPHERE, radius=sphereRadius)
colBoxId = p.createCollisionShape(p.GEOM_BOX,
                                  halfExtents=[sphereRadius, sphereRadius, sphereRadius])
print("collision ids: ", colSphereId, colBoxId)
mass = 1
visualShapeId = -1  # 没有外观

link_Masses = [1]  # 定义各个连杆的质量
linkCollisionShapeIndices = [colBoxId]
linkVisualShapeIndices = [-1]
linkPositions = [[0, 0, 0.11]]
linkOrientations = [[0, 0, 0, 1]]
linkInertialFramePositions = [[0, 0, 0]]
linkInertialFrameOrientations = [[0, 0, 0, 1]]
indices = [0]  # 在一个body中，base的id是0
jointTypes = [p.JOINT_REVOLUTE]
axis = [[0, 0, 1]]

for i in range(3):
    for j in range(3):
        for k in range(3):
            basePosition = [1 + i * 5 * sphereRadius, 1 + j * 5 * sphereRadius, 1 + k * 5 * sphereRadius + 1]
            baseOrientation = [0, 0, 0, 1]
            if k & 2:
                # 创建一个body，它是一个圆形的物体
                sphereUid = p.createMultiBody(mass,
                                              colSphereId,
                                              visualShapeId,
                                              basePosition,
                                              baseOrientation)
            else:
                # 创建一个body，它的base是一个colBoxId，它的child是linkCollisionShapeIndices
                # 所以，这里所生成的body由两个立方体组成，一个是base，一个是child
                sphereUid = p.createMultiBody(mass,
                                              colBoxId,
                                              visualShapeId,  # -1，没有外观形状
                                              basePosition,
                                              baseOrientation,
                                              linkMasses=link_Masses,  # 定义各个连杆的质量
                                              linkCollisionShapeIndices=linkCollisionShapeIndices,  # 创建连杆
                                              linkVisualShapeIndices=linkVisualShapeIndices,
                                              linkPositions=linkPositions,  # 它和basePosition有什么区别？
                                              linkOrientations=linkOrientations,
                                              linkInertialFramePositions=linkInertialFramePositions,
                                              linkInertialFrameOrientations=linkInertialFrameOrientations,
                                              linkParentIndices=indices,  # 0指基座，规定的，看帮助文档。在内部程序里，它会不会减去1？
                                              linkJointTypes=jointTypes,
                                              linkJointAxis=axis
                                              )
            # changeDynamics对结果没什么影响，它有什么用途呢？
            #p.changeDynamics(sphereUid,
            #                 -1,  # 指base
            #                 spinningFriction=0.001,
            #                 rollingFriction=0.001,
            #                 linearDamping=0.0)
            # 设置连杆的相关信息
            for joint in range(p.getNumJoints(sphereUid)):
                p.setJointMotorControl2(sphereUid, joint, p.VELOCITY_CONTROL, targetVelocity=1, force=10)

p.setGravity(0, 0, -10)
p.setRealTimeSimulation(1)
#for i in range(p.getNumJoints(sphereUid)):
#    p.getJointInfo(sphereUid, i)

while 1:
    #keys = p.getKeyboardEvents()
    #print(keys)
    time.sleep(0.01)
