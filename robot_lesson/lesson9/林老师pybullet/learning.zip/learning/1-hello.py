# -*-coding:utf-8-*-
import pybullet as p
import time
import pybullet_data
import numpy as np

physicsClient = p.connect(p.GUI)
print(physicsClient)
# 添加pybullet的额外数据地址，使程序可以直接调用到内部的一些模型
p.setAdditionalSearchPath(pybullet_data.getDataPath())
# 影响碰撞效果
p.setGravity(0, 0, -10)
# 加载地面urdf
planeId = p.loadURDF('plane.urdf')
# 加载r2d2机器人，设置初始位置和姿态
startPos = [0, 0, 1]  # 有一米高，所以会有碰撞效果
startOrn = p.getQuaternionFromEuler([0, np.pi/4, 0])
boxId = p.loadURDF('1-visualRobotModel.urdf', startPos, startOrn)
# 设置base的质心的位置和姿态信息
p.resetBasePositionAndOrientation(boxId, startPos, startOrn)
for i in range(10000):
    p.stepSimulation()
    time.sleep(1. / 240.)
# 获取boxId的base的位置和姿态信息
cubePos, cubeOrn = p.getBasePositionAndOrientation(boxId)
print(cubePos, cubeOrn)
p.disconnect()
