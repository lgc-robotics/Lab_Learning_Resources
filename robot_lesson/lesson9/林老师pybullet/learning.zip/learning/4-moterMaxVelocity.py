# -*-coding:utf-8-*-
import pybullet as p
import time
import pybullet_data

p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
cartpole = p.loadURDF("cartpole.urdf")
# 设置了setRealTimeSimulation，就不用stepSimulation！！！
p.setRealTimeSimulation(1)

"""
可以把1改为0，看看效果

注意：在POSITION_CONTROL模式下，我们的目标是获得targetPosition，而不是targetVelocity。
这不意味着targetVelocity和velocityGain要设置为0；这两个值设置为某个值时，会有利于算法收敛。
pybullet是用C++写的，最底层的代码看不到，我们可以通过试验倒推出它的算法原理。
对于POSITION_CONTROL，它用到了targetVelocity和velocityGain两个信息来设计算法。
"""

p.setJointMotorControl2(cartpole,
                        1,
                        p.POSITION_CONTROL,
                        targetPosition=10,  # 所指定关节的目标位置
                        targetVelocity=10,  # 在位置控制时，这个不一定要设置为0。具体原因看setJointMotorControl2的源码了
                        force=1000,
                        positionGain=1,
                        velocityGain=1,  # 在位置控制时，这个不一定要设置为0。具体原因看setJointMotorControl2的源码了
                        maxVelocity=0.5
                        )
p.setGravity(0, 0, -10)

while 1:
    js = p.getJointState(cartpole, 1)
    print("position=", js[0], "velocity=", js[1])
    time.sleep(0.01)
    # 由于已经设置了setRealTimeSimulation，所以这里不用stepSimulation


