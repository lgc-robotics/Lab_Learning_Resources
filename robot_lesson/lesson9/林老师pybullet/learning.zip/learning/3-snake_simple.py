# -*-coding:utf-8-*-
import pybullet as p
import time
import math
import pybullet_data
import numpy as np

p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
plane = p.createCollisionShape(p.GEOM_PLANE)
planeUid = p.createMultiBody(0, plane)
print('plane id:', planeUid)

useMaximalCoordinates = True
sphereRadius = 0.25
colBaseId = p.createCollisionShape(p.GEOM_BOX,
                                   halfExtents=[sphereRadius, 2*sphereRadius, sphereRadius])
colBoxId = p.createCollisionShape(p.GEOM_BOX,
                                  halfExtents=[sphereRadius, sphereRadius, sphereRadius])

mass = 1
visualShapeId = -1

link_Masses = []
linkCollisionShapeIndices = []
linkVisualShapeIndices = []
linkPositions = []
linkOrientations = []
linkInertialFramePositions = []
linkInertialFrameOrientations = []
indices = []
jointTypes = []
axis = []

for i in range(36):
    link_Masses.append(1)
    linkCollisionShapeIndices.append(colBoxId)
    linkVisualShapeIndices.append(-1)
    if i == 0:
        linkPositions.append([0, sphereRadius * 3.0 + 0.01, 0])
    else:
        linkPositions.append([0, sphereRadius * 2.0 + 0.01, 0])
    linkOrientations.append([0, 0, 0, 1])
    linkInertialFramePositions.append([0, 0, 0])
    linkInertialFrameOrientations.append([0, 0, 0, 1])
    indices.append(i)
    jointTypes.append(p.JOINT_REVOLUTE)
    axis.append([0, 0, 1])

basePosition = [0, 0, 1]
baseOrientation = p.getQuaternionFromEuler([np.pi/4, 0, 0])
# 我的个人理解：前5个参数用于定义base link，后面是附着在base link上的child link。
# createMultiBody的功能跟URDF很像，有必要先理解URDF。
sphereUid = p.createMultiBody(mass,  # mass of the base, in kg
                              colBaseId,  # base的collision shape, 一个实例
                              visualShapeId,  # base的visual shape，一个实例
                              basePosition,  # Cartesian world position of the base
                              baseOrientation,  # Cartesian world orientation of the base
                              linkMasses=link_Masses,
                              linkCollisionShapeIndices=linkCollisionShapeIndices,
                              linkVisualShapeIndices=linkVisualShapeIndices,
                              linkPositions=linkPositions,
                              linkOrientations=linkOrientations,
                              linkInertialFramePositions=linkInertialFramePositions,
                              linkInertialFrameOrientations=linkInertialFrameOrientations,
                              linkParentIndices=indices,
                              linkJointTypes=jointTypes,
                              linkJointAxis=axis,
                              useMaximalCoordinates=useMaximalCoordinates
                              )

#for joint in range(p.getNumJoints(sphereUid)):
#    p.setJointMotorControl2(sphereUid, joint, p.VELOCITY_CONTROL, targetVelocity=1, force=100)

p.setGravity(0, 0, -10)
p.setRealTimeSimulation(0)

for i in range(10000):
    p.stepSimulation()
    time.sleep(1. / 240.)
