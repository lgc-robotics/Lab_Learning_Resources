# -*-coding:utf-8-*-
import pybullet_data
import time
import pybullet as p
import numpy as np

p.connect(p.GUI)

p.setAdditionalSearchPath(pybullet_data.getDataPath())
q = p.loadURDF("quadruped/quadruped.urdf", useFixedBase=True)
rollId = p.addUserDebugParameter("roll", -1.5, 1.5, np.pi/4)
pitchId = p.addUserDebugParameter("pitch", -1.5, 1.5,  -np.pi/2)
yawId = p.addUserDebugParameter("yaw", 0, 2*3.14, 3.14)
fwdxId = p.addUserDebugParameter("fwdxId", -1, 1, 0)
fwdyId = p.addUserDebugParameter("fwdyId", -1, 1, 0)
fwdzId = p.addUserDebugParameter("fwdzId", -1, 1, 0)

while True:
    roll = p.readUserDebugParameter(rollId)
    pitch = p.readUserDebugParameter(pitchId)
    yaw = p.readUserDebugParameter(yawId)
    x = p.readUserDebugParameter(fwdxId)
    y = p.readUserDebugParameter(fwdyId)
    z = p.readUserDebugParameter(fwdzId)

    # The X,Y,Z Euler angles are in radians, accumulating 3 rotations
    # expressing the roll around the X, pitch around Y and yaw around
    # the Z axis.
    # 蔡自兴的RPY是依次绕Z-Y-X轴，而pybullet是依次绕X-Y-Z轴，要注意
    # 另外，这里把欧拉角和RPY混合到一起，因为欧拉角旋转顺序为Y-Y-Z时，它们的结果是一致的
    orn = p.getQuaternionFromEuler([roll, pitch, yaw])
    p.resetBasePositionAndOrientation(q, [x, y, z], orn)
