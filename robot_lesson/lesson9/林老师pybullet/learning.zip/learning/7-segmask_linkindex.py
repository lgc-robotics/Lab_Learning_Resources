# -*-coding:utf-8-*-

"""
一个机器人通常有多个连杆，如果不进行设置，这些连杆在getCameraImage中被视为一个物体。
可以把getCameraImage的参数flags = p.ER_SEGMENTATION_MASK_OBJECT_AND_LINKINDEX，
那么所输出的mask将区分各个连杆
"""

import pybullet as p
import pybullet_data

p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
r2d2 = p.loadURDF("r2d2.urdf", [0, 0, 1])
for l in range(p.getNumJoints(r2d2)):
    print(p.getJointInfo(r2d2, l))

p.loadURDF("r2d2.urdf", [2, 0, 1])
p.loadURDF("r2d2.urdf", [4, 0, 1])

p.getCameraImage(320, 200, flags=p.ER_SEGMENTATION_MASK_OBJECT_AND_LINKINDEX)
segLinkIndex = 1
verbose = 0

while 1:
    keys = p.getKeyboardEvents()
    if ord('1') in keys:
        state = keys[ord('1')]
        if state & p.KEY_WAS_RELEASED:
            # 1
            verbose = 1 - verbose
    if ord('s') in keys:
        state = keys[ord('s')]
        if state & p.KEY_WAS_RELEASED:
            # 0
            segLinkIndex = 1 - segLinkIndex
    flags = 0
    if segLinkIndex:
        flags = p.ER_SEGMENTATION_MASK_OBJECT_AND_LINKINDEX

    img = p.getCameraImage(320, 200, flags=flags)
    seg = img[4]
    if verbose:
        for pixel in seg:
            if pixel.any() >= 0:
                obUid = pixel & ((1 << 24) - 1)
                linkIndex = (pixel >> 24) - 1
                print("obUid=", obUid, "linkIndex=", linkIndex)

    p.stepSimulation()
