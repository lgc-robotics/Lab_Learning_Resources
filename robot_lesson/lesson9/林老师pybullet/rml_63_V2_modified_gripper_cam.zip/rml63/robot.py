# -*-coding:utf-8-*-
import pybullet as p
import numpy as np
import copy
import math
import pybullet_data
import os
import time
import matplotlib.pyplot as plt


def nums2str(data):
    out = ''
    for num in data:
        num = f'{num:.4f}'[:-1]
        out += ' ' + num
    return out


class Robot:
    def __init__(self, urdfRootPath):
        self.urdfRootPath = urdfRootPath

        self.maxVelocity = 10
        self.maxForce = 800
        self.useSimulation = 1

        # self.endEffectorIndex = 6

        self.cameraIndex = 12  # 在机器人中的索引号
        self.cameraWidth = 640
        self.cameraHeight = 480
        self.cameraFov = 60
        self.cameraTargetPos = [0, 0, 1]
        self.cameraRGBPosOnMassFrame = [0, -0.03, 0.0125]  # RGB镜头在realsense上的位置

        # self.useNullSpace = 21
        # self.useOrientation = 1
        # self.fingerAForce = 2
        # self.fingerBForce = 2.5
        # self.fingerTipForce = 2
        # self.useInverseKinematics = 1
        # self.gripperIndex = 7

        self.reset()

    def reset(self):
        """
        需在外部运行p.stepSimulation()
        """
        self.robotUid = p.loadURDF(os.path.join(self.urdfRootPath, "rm_63_1_b_description.urdf"),
                                   useFixedBase=True)
        # 通过大量实验调出来的
        startPos = [0.00072899, -0.00003499, 0.04226199]
        startOrn = p.getQuaternionFromEuler([0, 0, 0])
        p.resetBasePositionAndOrientation(self.robotUid, startPos, startOrn)

        # 13个joints
        # 0-5号指机器人关节
        # 6号是固定的，它把末端执行器固定到机器人法兰上
        # 7-10号用于控制末端执行器，由于机构是对称的，7=9,8=10
        # 11号是固定的，它把相机架固定到机器人法兰上
        # 12号是固定的，它把相机固定到相机架上
        self.jointPositions = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

        self.numJoints = p.getNumJoints(self.robotUid)
        for jointIndex in range(self.numJoints):
            # resetJointState使机器人瞬间达到期望位置
            p.resetJointState(self.robotUid, jointIndex, self.jointPositions[jointIndex])
            # setJointMotorControl2通过PD控制让机器人稳定在期望位置
            # 这里面没有stepSimulation函数，那么在外部应该要添加
            p.setJointMotorControl2(self.robotUid,
                                    jointIndex,
                                    p.POSITION_CONTROL,
                                    targetPosition=self.jointPositions[jointIndex],
                                    force=self.maxForce)

        # 获取能够运动的关节（有些关节是固定的）
        # [0, 1, 2, 3, 4, 5, 7, 8, 9, 10]
        self.motorIndices = []
        self.motorNames = []
        for i in range(self.numJoints):
            jointInfo = p.getJointInfo(self.robotUid, i)
            qIndex = jointInfo[3]
            if qIndex > -1:
                # print("motorname")
                # print(jointInfo[1])
                self.motorNames.append(str(jointInfo[1]))
                self.motorIndices.append(i)

    def showEndEffectorFrame(self, offset=[0, 0, 0.13]):
        """
        offset: [0.13, 0, 0]， 0.13指工具长度
        endPos: 工具在世界坐标系上的位置
        注意：由于URDF中末端执行器的连杆坐标系比较乱，这里用法兰的位置和姿态来解算工具在世界坐标系上的位置
        """
        # 获取法兰上的位置和姿态信息
        info = p.getLinkState(self.robotUid, 5, computeForwardKinematics=True)
        linkPos = info[4]
        linkOrn = info[5]
        rot_matrix = p.getMatrixFromQuaternion(linkOrn)
        rot_matrix = np.array(rot_matrix).reshape(3, 3)

        # 求末端信息
        endPos = np.array(linkPos) + rot_matrix.dot(np.array(offset))

        # 显示坐标系
        p.addUserDebugLine(endPos, endPos + 0.1 * rot_matrix.dot((1, 0, 0)), (1, 0, 0), lifeTime=0.2)
        p.addUserDebugLine(endPos, endPos + 0.1 * rot_matrix.dot((0, 1, 0)), (0, 1, 0), lifeTime=0.2)
        p.addUserDebugLine(endPos, endPos + 0.1 * rot_matrix.dot((0, 0, 1)), (0, 0, 1), lifeTime=0.2)

        # 显示末端的位置和姿态
        rpy = np.array(p.getEulerFromQuaternion(linkOrn))
        # textColor = [0, 0, 0]
        # p.addUserDebugText('End effector',[4, -2, 1.19], textColor, lifeTime=0.1)
        # p.addUserDebugText('xyz: ' + nums2str(endPos), [4, -2, 1], textColor, lifeTime=0.1)
        # p.addUserDebugText('rpy: ' + nums2str(rpy), [4, -2, 1.15], textColor, lifeTime=0.1)

        endPos = endPos*1000.0
        print("End-effector pos: {:.3f}, {:.3f}, {:.3f}".format(endPos[0], endPos[1], endPos[2]))
        print("End-effector rpy: {:.3f}, {:.3f}, {:.3f}".format(rpy[0], rpy[1], rpy[2]))

        return endPos

    def getExtendedObservation(self):
        """
        该函数很耗时，有必要时再使用
        Return:
            rgb-(480, 640, 4) uint8
            depth-(480, 640) float32
            mask-(480, 640) int32
        """
        proj_matrix = p.computeProjectionMatrixFOV(fov=self.cameraFov,
                                                   aspect=float(self.cameraHeight) / self.cameraWidth,
                                                   nearVal=0.03,
                                                   farVal=5.0)
        # Center of mass position and orientation
        com_p, com_o, _, _, _, _ = p.getLinkState(self.robotUid, self.cameraIndex, computeForwardKinematics=True)
        rot_matrix = p.getMatrixFromQuaternion(com_o)
        rot_matrix = np.array(rot_matrix).reshape(3, 3)
        # initial vectors
        init_camera_vector = (0, 0, 1)  # z-axis
        init_up_vector = (1, 0, 0)  # y-axis
        camera_vector = rot_matrix.dot(init_camera_vector)
        up_vector = rot_matrix.dot(init_up_vector)
        # 我们使用realsense上的RGB相机采集图像，把RGB相机转换到世界坐标系上
        com_p = rot_matrix.dot(self.cameraRGBPosOnMassFrame) + com_p
        view_matrix = p.computeViewMatrix(com_p, com_p + 0.1 * camera_vector, up_vector)
        # 显示相机坐标系
        p.addUserDebugLine(com_p, com_p + 0.1 * rot_matrix.dot((1, 0, 0)), (1, 0, 0), lifeTime=0.2)
        p.addUserDebugLine(com_p, com_p + 0.1 * rot_matrix.dot((0, 1, 0)), (0, 1, 0), lifeTime=0.2)
        p.addUserDebugLine(com_p, com_p + 0.1 * rot_matrix.dot((0, 0, 1)), (0, 0, 1), lifeTime=0.2)

        img_info = p.getCameraImage(width=self.cameraWidth,
                                    height=self.cameraHeight,
                                    viewMatrix=view_matrix,
                                    projectionMatrix=proj_matrix,
                                    renderer=p.ER_BULLET_HARDWARE_OPENGL)

        rgb = img_info[2]
        depth = img_info[3]
        mask = img_info[4]
        # print(rgb.shape, rgb.dtype, depth.shape, depth.dtype, mask.shape, mask.dtype)
        return rgb, depth, mask

    def debug(self):
        """
        该函数能独立运行
        """
        p.addUserDebugText('X', [1, 0, 0], [0, 0, 0])
        p.addUserDebugText('Y', [0, 1, 0], [0, 0, 0])
        p.addUserDebugText('Z', [0, 0, 1], [0, 0, 0])
        jointParamUids = []
        for i in range(len(self.motorIndices) - 2):
            name = "joint" + str(i)
            jointParamUids.append(p.addUserDebugParameter(name, -180., 180., 0))

        while 1:
            self.getExtendedObservation()
            self.showEndEffectorFrame()

            jointPoses = []
            for i in range(len(jointParamUids)):
                jointPoses.append(p.readUserDebugParameter(jointParamUids[i]) * np.pi / 180.)
            jointPoses.append(-1. * p.readUserDebugParameter(jointParamUids[-2]) * np.pi / 180.)
            jointPoses.append(-1. * p.readUserDebugParameter(jointParamUids[-1]) * np.pi / 180.)

            if self.useSimulation:
                p.stepSimulation()  # 如果没有它，物理引擎将失效，但仍可以显示
            time.sleep(1. / 240.)

            if self.useSimulation:
                for j in range(len(self.motorIndices)):
                    p.setJointMotorControl2(bodyIndex=self.robotUid,
                                            jointIndex=self.motorIndices[j],
                                            controlMode=p.POSITION_CONTROL,
                                            targetPosition=jointPoses[j],
                                            targetVelocity=0,
                                            force=self.maxForce,
                                            maxVelocity=self.maxVelocity,
                                            positionGain=0.3,
                                            velocityGain=1)
            else:
                for j in range(len(self.motorIndices)):
                    p.resetJointState(self.robotUid, self.motorIndices[j], jointPoses[j])

            # 显示法兰的位置和姿态
            ls = p.getLinkState(self.robotUid, 5)
            xyz = np.array(ls[4]) * 1000.
            orn = ls[5]
            rpy = np.array(p.getEulerFromQuaternion(orn))
            # textColor = [0, 0, 0]
            # p.addUserDebugText('Link 6', [2, -2, 1.2], textColor, lifeTime=0.1)
            # p.addUserDebugText('xyz: ' + nums2str(xyz), [2, -2, 1], textColor, lifeTime=0.1)
            # p.addUserDebugText('rpy: ' + nums2str(rpy), [2, -2, 1.15], textColor, lifeTime=0.1)
            # print("Link6 pos: {:.3f}, {:.3f}, {:.3f}".format(xyz[0], xyz[1], xyz[2]))
            # print("Link6 rpy: {:.3f}, {:.3f}, {:.3f}".format(rpy[0], rpy[1], rpy[2]))
