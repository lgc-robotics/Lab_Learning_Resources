# -*-coding:utf-8-*-
import pybullet as p
import time
import math
import pybullet_data
import numpy as np


def nums2str(data):
    out = ''
    for num in data:
        num = f'{num:.4f}'[:-1]
        out += ' ' + num
    return out


p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, -10)  # 影响碰撞效果

planeId = p.loadURDF('plane.urdf')
robot_id = p.loadURDF("./rml63/rm_63_1_b_description.urdf", useFixedBase=True)  # 导入机器人

startPos = [0.00072899, -0.00003499, 0.04226199]  # 这里有疑惑，需要花时间来解决
startOrn = p.getQuaternionFromEuler([0, 0, 0])
p.resetBasePositionAndOrientation(robot_id, startPos, startOrn)

jointPositions = [np.pi/4, np.pi/4, np.pi/4, np.pi/4, np.pi/4, np.pi/4, 0, 0, 0, 0, 0, 0, 0]  # 11个joints,其中6号joint是固定的

numJoints = p.getNumJoints(robot_id)
for jointIndex in range(numJoints):
    # resetJointState使机器人瞬间达到期望位置
    #p.resetJointState(robot_id, jointIndex, jointPositions[jointIndex])
    # setJointMotorControl2通过PID控制让机器人稳定在期望位置
    # 这里面没有stepSimulation函数，那么在外部应该要添加
    p.setJointMotorControl2(robot_id,
                            jointIndex,
                            p.POSITION_CONTROL,
                            targetPosition=jointPositions[jointIndex],
                            force=20.35)

while 1:
    p.stepSimulation()
    time.sleep(0.01)
