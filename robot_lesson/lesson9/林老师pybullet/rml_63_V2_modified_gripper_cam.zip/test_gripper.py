# -*-coding:utf-8-*-
import pybullet as p
import time
import math
import pybullet_data
import numpy as np


def nums2str(data):
    out = ''
    for num in data:
        num = f'{num:.4f}'[:-1]
        out += ' ' + num
    return out


p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, 0)  # 影响碰撞效果

planeId = p.loadURDF('plane.urdf')
robot_id = p.loadURDF("./rml63/jawasm1.urdf", [0.0425, 0, 0.01])  # 导入机器人

p.addUserDebugText('X', [1, 0, 0], [0, 0, 0])
p.addUserDebugText('Y', [0, 1, 0], [0, 0, 0])
p.addUserDebugText('Z', [0, 0, 1], [0, 0, 0])

j1id = p.addUserDebugParameter("joint 1", -180., 180., 0)
j2id = p.addUserDebugParameter("joint 2", -180., 180., 0)
j3id = p.addUserDebugParameter("joint 3", -180., 180., 0)
j4id = p.addUserDebugParameter("joint 4", -180., 180., 0)

useSimulation = False
numJoints = p.getNumJoints(robot_id)
print(numJoints)
while 1:
    jointPoses = []
    jointPoses.append(p.readUserDebugParameter(j1id) * np.pi / 180.)
    jointPoses.append(p.readUserDebugParameter(j2id) * np.pi / 180.)
    jointPoses.append(p.readUserDebugParameter(j3id) * np.pi / 180.)
    jointPoses.append(p.readUserDebugParameter(j4id) * np.pi / 180.)

    if useSimulation:
        p.stepSimulation()  # 如果没有它，物理引擎将失效，但仍可以显示
    time.sleep(1. / 240.)

    if useSimulation:
        for j in range(numJoints):
            p.setJointMotorControl2(bodyIndex=robot_id,
                                    jointIndex=j,
                                    controlMode=p.POSITION_CONTROL,
                                    targetPosition=jointPoses[j],
                                    targetVelocity=0,
                                    force=500,
                                    positionGain=0.03,
                                    velocityGain=1)
    else:
        for j in range(numJoints):
            p.resetJointState(robot_id, j, jointPoses[j])
    # 显示虚拟点的位置
    visualpointIndex = numJoints - 1
    ls = p.getLinkState(robot_id, visualpointIndex)
    xyz = np.array(ls[4]) * 1000.
    orn = ls[5]
    rpy = np.array(p.getEulerFromQuaternion(orn))
    textColor = [0, 0, 0]
    p.addUserDebugText('xyz: ' + nums2str(xyz),
                       [-2, 0, 1],
                       textColor,
                       lifeTime=0.1)
    p.addUserDebugText('rpy: ' + nums2str(rpy),
                       [-2, 0, 1.2],
                       textColor,
                       lifeTime=0.1)

    # print(ls)

p.disconnect()
