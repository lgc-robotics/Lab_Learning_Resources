# -*-coding:utf-8-*-
from rml63.robot import Robot
import pybullet as p
import pybullet_data

p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, -10)
planeId = p.loadURDF('plane.urdf')
p.loadURDF("r2d2.urdf", [1, 0, 0])

robotUrdfPath = "./rml63/"
robot = Robot(robotUrdfPath)
robot.debug()
